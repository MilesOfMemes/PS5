import React from "react";
import axios from "axios";

function Edit() {
    return(
        <h2>Edit</h2>
    ) 
    
   
  }

export default Edit;